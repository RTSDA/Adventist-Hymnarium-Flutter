#!/bin/bash

# Must run as root
if [ "$(id -u)" -ne 0 ]; then
    echo "Please run as root or with sudo"
    exit 1
fi

# Install directory
INSTALL_DIR="/opt/Adventist Hymnarium"

# Clean installation - remove existing directory if it exists
echo "Cleaning previous installation..."
if [ -d "$INSTALL_DIR" ]; then
    rm -rf "$INSTALL_DIR"
fi

# Create directories
mkdir -p "$INSTALL_DIR"

# Extract application
echo "Extracting application files..."
tar -xzf adventist_hymnarium.tar.gz -C "$INSTALL_DIR"

# Check if we have a nested bundle directory
if [ -d "$INSTALL_DIR/bundle" ]; then
    echo "Found nested bundle directory, moving files..."
    # Use cp instead of mv to avoid directory conflicts
    cp -a "$INSTALL_DIR/bundle/"* "$INSTALL_DIR/"
    # Remove the bundle directory after copying
    rm -rf "$INSTALL_DIR/bundle"
fi

# Find the executable
EXEC_PATH=$(find "$INSTALL_DIR" -type f -executable -name "adventist_hymnarium" | head -1)

if [ -z "$EXEC_PATH" ]; then
    echo "Executable not found. Looking for any executable file..."
    EXEC_PATH=$(find "$INSTALL_DIR" -type f -executable | head -1)

    if [ -z "$EXEC_PATH" ]; then
        echo "ERROR: No executable found in the extracted files."
        exit 1
    fi
fi

echo "Found executable at: $EXEC_PATH"

# Make executable
chmod +x "$EXEC_PATH"

# Create symlink
ln -sf "$EXEC_PATH" /usr/local/bin/adventist_hymnarium

# Look for icon in the known location
ICON_DIR="$INSTALL_DIR/data/flutter_assets/assets/icon"
if [ -d "$ICON_DIR" ]; then
    # Look for image files in the icon directory
    for ext in png jpg jpeg svg; do
        ICON_PATH=$(find "$ICON_DIR" -name "*.${ext}" | head -1)
        if [ -n "$ICON_PATH" ]; then
            break
        fi
    done

    if [ -n "$ICON_PATH" ]; then
        echo "Found icon at: $ICON_PATH"

        # Install icon in multiple sizes for better DE integration
        for size in 16 22 24 32 48 64 128 256; do
            ICON_INSTALL_DIR="/usr/share/icons/hicolor/${size}x${size}/apps"
            mkdir -p "$ICON_INSTALL_DIR"
            ICON_INSTALL_PATH="$ICON_INSTALL_DIR/adventist-hymnarium.png"

            # Convert and resize if ImageMagick is available
            if command -v convert &> /dev/null; then
                echo "Installing ${size}x${size} icon..."
                convert "$ICON_PATH" -resize ${size}x${size} "$ICON_INSTALL_PATH"
            elif [ "$size" = "128" ]; then
                # If no ImageMagick, at least copy the original to one size
                cp "$ICON_PATH" "$ICON_INSTALL_PATH"
            fi
        done

        # Also install with alternative names (for different desktop environments)
        cp "/usr/share/icons/hicolor/128x128/apps/adventist-hymnarium.png" "/usr/share/icons/hicolor/128x128/apps/adventist_hymnarium.png"

        echo "Installed icons in system locations"
    fi
fi

# First, remove any existing desktop files to avoid duplicates
rm -f /usr/share/applications/adventist-hymnarium.desktop
rm -f /usr/share/applications/adventist_hymnarium.desktop
rm -f /usr/share/applications/com.benjaminslingo.adventist_hymnarium.desktop
rm -f /usr/share/cinnamon/applications/adventist-hymnarium.desktop

# Create a single desktop file with the correct name
cat > /usr/share/applications/adventist-hymnarium.desktop << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Adventist Hymnarium
GenericName=Hymnal
Comment=Browse and enjoy Adventist Hymns
Exec=adventist_hymnarium
Icon=adventist-hymnarium
Categories=AudioVideo;Music;Education;Religion;
Terminal=false
StartupWMClass=com.benjaminslingo.adventist_hymnarium
# Prevent duplicate display names
NoDisplay=false
X-GNOME-FullName=Adventist Hymnarium
EOF

# Set proper permissions for desktop file
chmod 644 /usr/share/applications/adventist-hymnarium.desktop

# For Cinnamon specifically
if command -v cinnamon &> /dev/null || [ -d "/usr/share/cinnamon" ]; then
    echo "Detected Cinnamon desktop, applying Cinnamon-specific fixes..."

    # Create a copy in Cinnamon's own applications directory
    mkdir -p /usr/share/cinnamon/applications/
    cp /usr/share/applications/adventist-hymnarium.desktop /usr/share/cinnamon/applications/
fi

# Update desktop database and icon cache
echo "Updating desktop database and icon cache..."
if command -v update-desktop-database &> /dev/null; then
    update-desktop-database -q /usr/share/applications
fi

if command -v gtk-update-icon-cache &> /dev/null; then
    gtk-update-icon-cache -f -t /usr/share/icons/hicolor
fi

# Try to restart Cinnamon's menu applet if running
if pgrep -x "cinnamon" > /dev/null; then
    echo "Restarting Cinnamon menu..."
    dbus-send --session --dest=org.Cinnamon --type=method_call /org/Cinnamon org.Cinnamon.ReloadXlet string:'panel' string:'menu@cinnamon.org' >/dev/null 2>&1 || true
fi

echo "Installation complete. Run 'adventist_hymnarium' or find in application menu."
echo "Note: You may need to log out and log back in for the application to appear correctly in some desktop environments."

