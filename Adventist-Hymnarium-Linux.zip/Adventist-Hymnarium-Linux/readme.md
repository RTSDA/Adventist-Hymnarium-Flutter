
Adventist Hymnarium is an application that provides access to Adventist hymns. This package contains everything needed to install the application on Linux systems.

System Requirements
Linux-based operating system
Root/sudo privileges for installation
Recommended: GTK-based desktop environment (GNOME, Cinnamon, MATE, Xfce, etc.)
Installation Instructions
Extract the package



Bash
unzip adventist_hymnarium_linux.zip
cd adventist_hymnarium_linux
Run the installation script



Bash
sudo ./install.sh
Launch the application
After installation, you can launch Adventist Hymnarium in two ways:

From your application menu (look in the "Music" or "Religion" category)
From the terminal by typing: adventist_hymnarium
If the application doesn't appear in your menu immediately, try logging out and back in.

Uninstallation
To remove Adventist Hymnarium from your system:




Bash
sudo ./install.sh --uninstall
Troubleshooting
If you encounter any issues during installation:

Application doesn't appear in menu

Log out and log back in to refresh the menu cache
Try running from terminal: adventist_hymnarium
Permission errors during installation

Make sure you're running the script with sudo
Check that the script is executable: chmod +x install.sh
Other issues

Check the terminal output for specific error messages
Contact support with the error details
Package Contents
This package includes:

README.md - This file
install.sh - Installation script
adventist_hymnarium.tar.gz - Application files
Support
For support, bug reports, or feature requests, please visit:
https://github.com/benjaminslingo/adventist-hymnarium-flutter

Thank you for using Adventist Hymnarium!
